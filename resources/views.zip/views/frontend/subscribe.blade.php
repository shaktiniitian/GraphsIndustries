    <!--Subscribe Form-->
    <section class="subscribe-form">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<div class="column col-md-5 col-sm-5 col-xs-12">
                	<h2>SUBSCRIBE FOR LATEST UPDATES</h2>
                </div>
                <div class="column col-md-7 col-sm-7 col-xs-12">
                	<div class="newsletter-style-one">
                    	<form method="post" action="http://wp1.themexlab.com/2017/leeds/leeds/contact.html">
                        	<div class="form-group">
                            	<input type="email" name="email" value="" placeholder="Enter your email id..." required>
                                <button type="submit" class="theme-btn"><span class="icon flaticon-send-message-button"></span> SUBSCRIBE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Subscribe Form-->
    
